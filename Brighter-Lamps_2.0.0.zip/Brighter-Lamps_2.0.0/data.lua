--Changes to Small Lamp
if data.raw["lamp"]["small-lamp"] then
    data.raw["lamp"]["small-lamp"].light.size = settings.startup["light-size"].value
end
